import admin from "firebase-admin";
import fs from "fs";
import dotenv from "dotenv";

dotenv.config();

console.log("--- SDK Config Debug Script ---");

let serviceAccount;
try {
    const data = fs.readFileSync("./serviceAccountKey.json", "utf8");
    serviceAccount = JSON.parse(data);
} catch (err) {
    console.error("Error loading serviceAccountKey.json:", err.message);
    process.exit(1);
}

// Initialize with explicit projectId
try {
    admin.initializeApp({
        credential: admin.credential.cert(serviceAccount),
        projectId: serviceAccount.project_id // Explicitly setting this
    });
    console.log("Firebase App Initialized with Explicit Project ID.");
} catch (err) {
    console.error("Error initializing app:", err);
}

const db = admin.firestore();
// Force usage of 'default' without parentheses if possible, or use explicit routing
// Note: SDK usually normalizes this. We try to be explicit.
db.settings({ databaseId: 'default', preferRest: true });

async function testSDK() {
    try {
        console.log("1. Attempting listCollections()...");
        const collections = await db.listCollections();
        console.log(`   Success. Found ${collections.length} collections.`);
        collections.forEach(c => console.log(`   - ${c.id}`));

        console.log("2. Attempting to write to 'debug_test'...");
        const ref = await db.collection("debug_test").add({
            timestamp: admin.firestore.FieldValue.serverTimestamp(),
            message: "Explicit ProjectID Test"
        });
        console.log("   SUCCESS! Document ID:", ref.id);

    } catch (err) {
        console.error("FAILURE. Error details:");
        console.error("Code:", err.code);
        console.error("Message:", err.message);
    }
}

testSDK();
