import admin from 'firebase-admin';
import fs from 'fs';

const serviceAccount = JSON.parse(fs.readFileSync('./serviceAccountKey.json', 'utf8'));

if (!admin.apps.length) {
    admin.initializeApp({
        credential: admin.credential.cert(serviceAccount),
        projectId: serviceAccount.project_id
    });
}

const db = admin.firestore();
db.settings({ preferRest: true });

async function checkQuestions() {
    console.log(`Connecting to Project: ${serviceAccount.project_id}`);
    console.log('--- Checking Questions Collection ---');
    try {
        const snap = await db.collection('questions').get();
        console.log(`Snapshot size: ${snap.size}`);

        if (snap.empty) {
            console.log('No questions found in database.');
            return;
        }

        snap.forEach(doc => {
            const data = doc.data();
            console.log(`\nID: ${doc.id}`);
            console.log(`Text: ${data.text}`);
            console.log(`Passage: ${data.passage ? (data.passage.substring(0, 30) + '...') : 'MISSING'}`);
            console.log(`Options Count: ${data.options ? data.options.length : 'MISSING'}`);
            if (data.options) {
                console.log(`Options: ${JSON.stringify(data.options)}`);
            }
            console.log(`TestID: ${data.testId}`);
        });
    } catch (err) {
        console.error('Error fetching questions:', err);
    }
}

checkQuestions().catch(console.error);
